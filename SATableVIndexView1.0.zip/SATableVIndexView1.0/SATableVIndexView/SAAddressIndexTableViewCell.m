//
//  SAAddressIndexTableViewCell.m
//  SATableVIndexView
//
//  Created by 刘畅 on 2021/12/27.
//

#import "SAAddressIndexTableViewCell.h"

@interface SAAddressIndexTableViewCell ()

@property (nonatomic, strong) UIButton *wordBtn;

@end

@implementation SAAddressIndexTableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
        [self setUI];
        
    }
    
    return self;
}

#pragma mark - 设置视图
- (void)setUI {
    
    self.backgroundColor = [UIColor clearColor];
    [self addSubview:self.wordBtn];
    
}

- (void)setData:(NSString *)word H:(CGFloat)h IsBtnSelect:(BOOL)isBtnSelect {
    
    [self.wordBtn setTitle:word forState: UIControlStateNormal];
    
    self.wordBtn.frame = CGRectMake(0, (h-16.f)/2, 16.f, 16.f);
    
    if (isBtnSelect == true){
        [_wordBtn setBackgroundColor:[UIColor colorWithRed:243.f/255.0 green:200.f/255.0 blue:69.f/255.0 alpha:1]];
        [_wordBtn setTitleColor:[UIColor whiteColor] forState: UIControlStateNormal];
    }else {
        [_wordBtn setBackgroundColor:[UIColor clearColor]];
        [_wordBtn setTitleColor:[UIColor colorWithRed:153.f/255.0 green:153.f/255.0 blue:153.f/255.0 alpha:1] forState: UIControlStateNormal];
    }
    
}
- (UIButton *)wordBtn {
    
    if (!_wordBtn) {
        _wordBtn = [UIButton buttonWithType: UIButtonTypeCustom];
        _wordBtn.frame = CGRectMake(0, 0, 16, 16);
        [_wordBtn setTitleColor:[UIColor colorWithRed:153.f/255.0 green:153.f/255.0 blue:153.f/255.0 alpha:1] forState: UIControlStateNormal];
        _wordBtn.titleLabel.font = [UIFont systemFontOfSize:11];
        _wordBtn.layer.masksToBounds = YES;
        _wordBtn.layer.cornerRadius = 8;
    }
    
    return _wordBtn;
}

@end
