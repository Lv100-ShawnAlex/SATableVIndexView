//
//  SAModel.h
//  SATableVIndexView
//
//  Created by 刘畅 on 2021/12/27.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface SAModel : NSObject

@property (nonatomic, strong) NSArray *testKeyArr;
@property (nonatomic, strong) NSArray *testContentArr;

@end

NS_ASSUME_NONNULL_END
