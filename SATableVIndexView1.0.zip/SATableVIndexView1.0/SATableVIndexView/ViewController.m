//
//  ViewController.m
//  SATableVIndexView
//
//  Created by ShawnAlex on 2021/12/27.
//

#import "ViewController.h"
#import "SAModel.h"
#import "SATableViewCell.h"
#import "SATableHeaderView.h"
#import "SAModel.h"
#import "SAAddressIndexView.h"

#define SCREEN_WIDTH [[UIScreen mainScreen] bounds].size.width
#define SCREEN_HEIGHT [[UIScreen mainScreen] bounds].size.height

@interface ViewController ()<UITableViewDelegate, UITableViewDataSource, SAAddressIndexDelegate>

@property (nonatomic, strong) SAAddressIndexView *addIndexView;
@property (nonatomic, strong) UIImageView *showImg;
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) UILabel *kLab;
@property (nonatomic, strong) SAModel *model;
@property (nonatomic, strong) NSArray *cityArr;
@property (nonatomic, strong) NSArray *cityWordArr;
@property (nonatomic, assign) NSInteger nowScrollIndex;
@property (nonatomic, assign) BOOL scrollBool;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.title = @"测试";
    [self setUI];
    
}

#pragma mark - 设置UI

- (void)setUI {
    
    [self.view addSubview: self.tableView];
    [self.view addSubview: self.kLab];
    self.kLab.hidden = true;
    
    [self.view addSubview: self.addIndexView];
    
    self.scrollBool = true;
    self.nowScrollIndex = 0;
    
    self.view.userInteractionEnabled = YES;
    
}

#pragma mark - 列表模块

- (UITableView *)tableView {
    
    if (!_tableView) {

        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT - 10.f) style:UITableViewStyleGrouped];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.showsVerticalScrollIndicator = NO;
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _tableView.backgroundColor = [UIColor colorWithRed:246/255.0 green:246/255.0 blue:246/255.0 alpha:1];
        [_tableView registerClass:[SATableViewCell class] forCellReuseIdentifier:@"SACell"];
        [_tableView registerClass:[SATableHeaderView class] forHeaderFooterViewReuseIdentifier:@"SAHeader"];
        
    }
    
    return _tableView;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section {
    
    SATableHeaderView *v = [tableView dequeueReusableHeaderFooterViewWithIdentifier:@"SAHeader"];
    v.frame = CGRectMake(0, 0, SCREEN_WIDTH, 35.f);
    [v setData: self.cityWordArr[section]];
    return v;
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    
    return 43.f;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    
    return self.cityWordArr.count;
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    
    NSArray *arr = self.cityArr[section];
    return arr.count;
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
   return 48.f;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {

    SATableViewCell *cell = [tableView dequeueReusableCellWithIdentifier: @"SACell"];
    NSArray *arr = self.cityArr[indexPath.section];
    NSString *city = arr[indexPath.row];
    [cell setData:city ShowLine:indexPath.row == arr.count - 1];
    [cell setSelectionStyle:UITableViewCellSelectionStyleNone];
    return cell;
    
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    
    if (self.scrollBool) {
        
        CGFloat statusH = self.view.window.windowScene.statusBarManager.statusBarFrame.size.height;
        CGFloat navH = self.navigationController.navigationBar.frame.size.height;
        CGFloat d = statusH + navH + 10.f;
        
        for(int i = 1; i < self.cityWordArr.count; i++){
            
            CGFloat bottomCellOffset1 = [self.tableView rectForSection:i - 1].origin.y - d;
            CGFloat bottomCellOffset2 = [self.tableView rectForSection:i].origin.y - d;
            
            if (scrollView.contentOffset.y < bottomCellOffset2 && scrollView.contentOffset.y >= bottomCellOffset1) {
            
                self.addIndexView.selWordIndex = i - 1;
                
            }else if (i == self.cityWordArr.count - 1 && scrollView.contentOffset.y >= bottomCellOffset2) {
             
                self.addIndexView.selWordIndex = self.cityWordArr.count - 1;
                
            }
            
            if (self.nowScrollIndex != self.addIndexView.selWordIndex) {
                [self.addIndexView.tableV reloadData];
                self.nowScrollIndex = self.addIndexView.selWordIndex;
                break;
            }
            
        }
    }

}

#pragma mark - 调用/回调方法

- (void)addressIndexSelect:(NSInteger)selindex {
    
    self.scrollBool = false;
    
    UILabel *lab = [[UILabel alloc] initWithFrame: CGRectMake(SCREEN_WIDTH - 100, CGRectGetMaxY(self.addIndexView.frame) - 190, 48, 48)];
    lab.textColor = [UIColor whiteColor];
    lab.textAlignment = 1;
    lab.font = [UIFont boldSystemFontOfSize:25];
    lab.backgroundColor = [UIColor colorWithRed:225/ 255.0 green:225/255.0 blue:225/255.0 alpha:1];
    lab.layer.masksToBounds = YES;
    lab.layer.cornerRadius = 24;
    lab.text = self.cityWordArr[selindex];
    [self.view addSubview:lab];
    
    self.kLab.hidden = YES;
    
    [self.tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:0 inSection:selindex] atScrollPosition:UITableViewScrollPositionTop animated:NO];
    
    self.nowScrollIndex = selindex;
    
    [UIView animateWithDuration:0.7 animations:^{
        lab.alpha = 0;
        
    } completion:^(BOOL finished) {
        [lab removeFromSuperview];
        self.scrollBool = true;
    }];
}

- (void)addressIndexScrollWord:(NSInteger)selindex {
    
    self.kLab.hidden = NO;
    self.kLab.text = self.cityWordArr[selindex];
    self.nowScrollIndex = selindex;
    
}

#pragma mark - 懒加载

- (SAModel *)model {
    
    if (!_model){
        
        _model = [[SAModel alloc] init];
        
    }
    
    return _model;
}

- (NSArray *)cityArr {
    
    if(!_cityArr) {
        _cityArr = self.model.testContentArr;
    }
    
    return _cityArr;
}

- (NSArray *)cityWordArr {
    
    if(!_cityWordArr) {
        _cityWordArr = self.model.testKeyArr;
    }
    
    return _cityWordArr;
}

- (SAAddressIndexView *)addIndexView {
    
    if (!_addIndexView) {
        
        _addIndexView = [[SAAddressIndexView alloc] initWithFrame:CGRectMake(SCREEN_WIDTH - 30, (SCREEN_HEIGHT - 420) / 2, 30, 420)];
        _addIndexView.delegate = self;
        [_addIndexView setData: self.cityWordArr];
        
    }
    
    return _addIndexView;
    
}

- (UILabel *)kLab {
    
    if(!_kLab){
        
        _kLab = [[UILabel alloc] initWithFrame: CGRectMake(SCREEN_WIDTH - 100, CGRectGetMaxY(self.addIndexView.frame) - 190, 48, 48)];
        _kLab.textColor = [UIColor whiteColor];
        _kLab.textAlignment = 1;
        _kLab.font = [UIFont boldSystemFontOfSize:25];
        _kLab.backgroundColor = [UIColor colorWithRed:225/ 255.0 green:225/255.0 blue:225/255.0 alpha:1];
        _kLab.layer.masksToBounds = YES;
        _kLab.layer.cornerRadius = 24;
        _kLab.hidden = true;
        
    }
    
    return _kLab;
}

@end
