//
//  OnlineOrderAddressIndexView.m
//  pingping
//
//  Created by 刘畅 on 2021/11/29.
//

#import "SAAddressIndexView.h"
#import "SAAddressIndexTableViewCell.h"

@interface SAAddressIndexView()<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) NSArray *dataArr;

@end

@implementation SAAddressIndexView

- (instancetype)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if (self) {
        [self setView];
    }
    return self;
    
}

- (void)setView {
    
    self.backgroundColor = [UIColor clearColor];
    [self addSubview:self.tableV];
    self.userInteractionEnabled = YES;
    
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(panAction:)];
    [self addGestureRecognizer:pan];
    
}

- (void)setData:(NSArray *)sendArr {
    
    self.dataArr = sendArr;
    [self.tableV reloadData];
    
}

- (UITableView *)tableV {
    
    if (!_tableV) {
        
        _tableV = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height) style:UITableViewStylePlain];
        _tableV.dataSource = self;
        _tableV.delegate = self;
        _tableV.scrollEnabled = NO;
        _tableV.backgroundColor = [UIColor clearColor];
        _tableV.separatorStyle = UITableViewCellSeparatorStyleNone;
        [_tableV registerClass:[SAAddressIndexTableViewCell class] forCellReuseIdentifier:@"SAAddIndexCell"];
        
    }
    
    return _tableV;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataArr.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (self.dataArr.count == 0){
        return 0;
    }
    
    return self.frame.size.height / self.dataArr.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    SAAddressIndexTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"SAAddIndexCell"];
    [cell setData:self.dataArr[indexPath.row] H:self.frame.size.height / self.dataArr.count IsBtnSelect:indexPath.row == self.selWordIndex];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    self.selWordIndex = indexPath.row;
    [self.delegate addressIndexSelect:indexPath.row];
    [self.tableV reloadData];
}


- (void)panAction:(UIGestureRecognizer *)sender {
    
    if (self.dataArr.count != 0){
        
        CGPoint point = [sender locationInView:self];
        
        if (sender.state == UIGestureRecognizerStateChanged) {
            
            self.selWordIndex = floor(point.y / (self.dataArr.count));
            
            if (self.selWordIndex < 0){
                
                self.selWordIndex = 0;
                
            }else if (self.selWordIndex > self.dataArr.count - 1){
                
                self.selWordIndex = self.dataArr.count - 1;
                
            }
            
            [self.delegate addressIndexScrollWord: self.selWordIndex];
            [self.tableV reloadData];
            
        }else if (sender.state == UIGestureRecognizerStateEnded) {
            
            [self.delegate addressIndexSelect:self.selWordIndex];
            
        }
        
    }
    
}

- (NSArray *)dataArr {
    
    if (!_dataArr){
        
        _dataArr = @[];
        
    }
    
    return _dataArr;
}

@end
