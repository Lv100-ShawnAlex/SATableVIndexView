//
//  SATableHeaderView.m
//  SATableVIndexView
//
//  Created by 刘畅 on 2021/12/27.
//

#import "SATableHeaderView.h"

#define SCREEN_WIDTH [[UIScreen mainScreen] bounds].size.width
#define SCREEN_HEIGHT [[UIScreen mainScreen] bounds].size.height

@interface SATableHeaderView ()

@property (nonatomic, strong) UILabel *sectionLab;

@end

@implementation SATableHeaderView

- (instancetype)initWithReuseIdentifier:(NSString *)reuseIdentifier {
    
    self = [super initWithReuseIdentifier:reuseIdentifier];
    
    if (self) {
        
        [self setUI];
        
    }
    
    return self;
}


- (void)setUI {
    
    [self addSubview: self.sectionLab];
    
}

- (void)setData:(NSString *)word {
    
    self.sectionLab.text = word;
}


- (UILabel *)sectionLab {
    
    if (!_sectionLab) {
        
        _sectionLab = [[UILabel alloc] initWithFrame:CGRectMake(13, 0, SCREEN_WIDTH - 26, 35.f)];

    }
    return _sectionLab;
    
}



@end
