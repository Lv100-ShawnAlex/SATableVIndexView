//
//  SATableViewCell.m
//  SATableVIndexView
//
//  Created by 刘畅 on 2021/12/27.
//

#import "SATableViewCell.h"

#define SCREEN_WIDTH [[UIScreen mainScreen] bounds].size.width
#define SCREEN_HEIGHT [[UIScreen mainScreen] bounds].size.height

@interface SATableViewCell ()

@property (nonatomic, strong) UILabel *nameLab;
@property (nonatomic, strong) UIView *lineV;

@end

@implementation SATableViewCell

- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        
        [self setUI];
        
    }
    
    return self;
}

#pragma mark - 设置视图
- (void)setUI {
    
    [self addSubview: self.nameLab];
    [self addSubview: self.lineV];
    
}


#pragma mark - 设置数据

- (void)setData:(NSString *)city ShowLine:(BOOL)isShowLine {
    
    self.nameLab.text = city;
    self.lineV.hidden = isShowLine;
    
}


#pragma mark - 懒加载


- (UILabel *)nameLab {
    
    if (!_nameLab) {
        
        _nameLab = [[UILabel alloc] initWithFrame:CGRectMake(31.f, 0, SCREEN_WIDTH - 50.f, 47.f)];
        _nameLab.textAlignment = 0;
        _nameLab.font = [UIFont systemFontOfSize:14];
    }
    
    return _nameLab;
}

- (UIView *)lineV {
    
    if (!_lineV){
        
        _lineV = [[UIView alloc] initWithFrame:CGRectMake(20.f, 47.5f, SCREEN_WIDTH - 40.f, 0.5)];
        _lineV.backgroundColor = [UIColor colorWithRed:246/255.0 green:246/255.0 blue:246/255.0 alpha:1];
        
    }
    
    return _lineV;
}

@end
