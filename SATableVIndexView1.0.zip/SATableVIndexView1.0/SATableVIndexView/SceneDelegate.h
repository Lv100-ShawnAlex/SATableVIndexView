//
//  SceneDelegate.h
//  SATableVIndexView
//
//  Created by ShawnAlex on 2021/12/27.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

