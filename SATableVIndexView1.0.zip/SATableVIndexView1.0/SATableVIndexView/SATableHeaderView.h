//
//  SATableHeaderView.h
//  SATableVIndexView
//
//  Created by 刘畅 on 2021/12/27.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SATableHeaderView : UITableViewHeaderFooterView

- (void)setData:(NSString *)word;

@end

NS_ASSUME_NONNULL_END
