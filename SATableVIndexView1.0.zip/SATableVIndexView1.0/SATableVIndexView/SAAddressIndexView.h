//
//  OnlineOrderAddressIndexView.h
//  pingping
//
//  Created by 刘畅 on 2021/11/29.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@protocol SAAddressIndexDelegate <NSObject>

- (void)addressIndexScrollWord:(NSInteger)selindex;
- (void)addressIndexSelect:(NSInteger)selindex;

@end

@interface SAAddressIndexView : UIView

@property (nonatomic, assign) id <SAAddressIndexDelegate> delegate;

- (void)setData:(NSArray *)sendArr;

@property (nonatomic, strong) UITableView *tableV;

@property (nonatomic, assign) NSInteger selWordIndex;

@end

NS_ASSUME_NONNULL_END
