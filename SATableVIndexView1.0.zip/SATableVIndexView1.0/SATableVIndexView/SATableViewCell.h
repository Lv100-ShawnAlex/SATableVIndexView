//
//  SATableViewCell.h
//  SATableVIndexView
//
//  Created by 刘畅 on 2021/12/27.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SATableViewCell : UITableViewCell

- (void)setData:(NSString *)city ShowLine:(BOOL)isShowLine;

@end

NS_ASSUME_NONNULL_END
